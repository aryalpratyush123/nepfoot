<header class="site-header">
  <div class="container">
    <h2><a href="/nepfoot_project/">NepFoot</a></h2>
    <nav>
      <a href="/nepfoot_project/">Home</a>
      <a href="/nepfoot_project/products.php">Products</a>
      <?php if (!isset($_SESSION)) session_start(); if(isset($_SESSION['user'])): ?>
        <a href="/nepfoot_project/dashboard.php">Dashboard</a>
        <a href="/nepfoot_project/logout.php">Logout (<?php echo htmlspecialchars($_SESSION['user']['email']); ?>)</a>
      <?php else: ?>
        <a href="/nepfoot_project/login.php">Login</a>
        <a href="/nepfoot_project/register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
