<?php
session_start();
require_once 'db.php';

function is_logged_in() {
    return isset($_SESSION['user']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /nepfoot_project/login.php');
        exit;
    }
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function esc($s) {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}
?>