<?php
require_once '../includes/functions.php';
require_login();
$user = current_user();
if ($user['role'] !== 'admin') { echo 'Access denied'; exit; }

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query('DELETE FROM users WHERE id='.$id);
    header('Location: users.php');
    exit;
}

$res = $conn->query('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Users - Admin</title><link rel="stylesheet" href="/nepfoot_project/assets/style.css"></head><body>
<?php include '../parts/header.php'; ?>
<main class="container card">
  <h2>Users</h2>
  <table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Created</th><th>Actions</th></tr>
  <?php while($r = $res->fetch_assoc()): ?>
    <tr>
      <td><?php echo $r['id']; ?></td>
      <td><?php echo htmlspecialchars($r['name']); ?></td>
      <td><?php echo htmlspecialchars($r['email']); ?></td>
      <td><?php echo $r['role']; ?></td>
      <td><?php echo $r['created_at']; ?></td>
      <td><a href="?delete=<?php echo $r['id']; ?>" onclick="return confirm('Delete user?')">Delete</a></td>
    </tr>
  <?php endwhile; ?>
  </table>
</main>
<?php include '../parts/footer.php'; ?>
</body></html>
