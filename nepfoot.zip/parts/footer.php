<footer class="site-footer">
  <div class="container">
    <small>&copy; NepFoot - College Project</small>
  </div>
</footer>
