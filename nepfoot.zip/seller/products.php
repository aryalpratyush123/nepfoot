<?php
require_once '../includes/functions.php';
require_login();
$user = current_user();
if ($user['role'] !== 'seller') { echo 'Access denied'; exit; }
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query('DELETE FROM products WHERE id='.$id.' AND seller_id=' . intval($user['id']));
    header('Location: products.php'); exit;
}
$res = $conn->query('SELECT * FROM products WHERE seller_id='.intval($user['id']).' ORDER BY created_at DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>My Products</title><link rel="stylesheet" href="/nepfoot_project/assets/style.css"></head><body>
<?php include '../parts/header.php'; ?>
<main class="container card">
  <h2>My Products <a class="btn" href="edit_product.php">Add</a></h2>
  <table><tr><th>ID</th><th>Name</th><th>Price</th><th>Actions</th></tr>
  <?php while($r = $res->fetch_assoc()): ?>
    <tr>
      <td><?php echo $r['id']; ?></td>
      <td><?php echo htmlspecialchars($r['name']); ?></td>
      <td><?php echo $r['price']; ?></td>
      <td><a href="edit_product.php?id=<?php echo $r['id']; ?>">Edit</a> | <a href="?delete=<?php echo $r['id']; ?>" onclick="return confirm('Delete?')">Delete</a></td>
    </tr>
  <?php endwhile; ?>
  </table>
</main>
<?php include '../parts/footer.php'; ?>
</body></html>
