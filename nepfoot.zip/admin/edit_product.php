<?php
require_once '../includes/functions.php';
require_login();
$user = current_user();
if ($user['role'] !== 'admin') { echo 'Access denied'; exit; }

$id = intval($_GET['id'] ?? 0);
$name=''; $price=''; $brand=''; $size=''; $description=''; $seller_id=''; $image='';
$errors=[];

# --- Load existing product for edit ---
if ($id) {
    $stmt = $conn->prepare('SELECT * FROM products WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $name        = $row['name'];
        $price       = $row['price'];
        $brand       = $row['brand'];
        $size        = $row['size'];
        $description = $row['description'];
        $seller_id   = $row['seller_id'];
        $image       = $row['image'];
    } else {
        echo 'Not found';
        exit;
    }
}

# --- Handle form submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name']);
    $price       = $_POST['price'];
    $brand       = $_POST['brand'];
    $size        = $_POST['size'];
    $description = $_POST['description'];
    $seller_id   = $_POST['seller_id'] ?: NULL;
    $new_image   = $image; // Keep old image unless replaced

    if (!$name) $errors[] = 'Name required';
    if (!is_numeric($price)) $errors[] = 'Price must be numeric';

    # --- Handle image upload ---
    if (!empty($_FILES['image']['name'])) {
        $targetDir = __DIR__ . '/../uploads/';
        if (!file_exists($targetDir)) mkdir($targetDir, 0777, true);

        $filename  = time() . '_' . basename($_FILES['image']['name']);
        $targetFile = $targetDir . $filename;
        $fileType   = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowed    = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($fileType, $allowed)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                $new_image = $filename;
                // Delete old image if replaced
                if ($id && !empty($image) && file_exists($targetDir . $image)) {
                    unlink($targetDir . $image);
                }
            } else {
                $errors[] = 'Failed to upload image.';
            }
        } else {
            $errors[] = 'Invalid image format (jpg, jpeg, png, gif allowed).';
        }
    }

    # --- Save to database ---
    if (empty($errors)) {
        if ($id) {
            $stmt = $conn->prepare('UPDATE products SET name=?,price=?,brand=?,size=?,description=?,seller_id=?,image=? WHERE id=?');
            $stmt->bind_param('sdsssisi', $name, $price, $brand, $size, $description, $seller_id, $new_image, $id);
            $stmt->execute();
        } else {
            $stmt = $conn->prepare('INSERT INTO products (name,price,brand,size,description,seller_id,image) VALUES (?,?,?,?,?,?,?)');
            $stmt->bind_param('sdsssis', $name, $price, $brand, $size, $description, $seller_id, $new_image);
            $stmt->execute();
        }
        header('Location: products.php');
        exit;
    }
}

# --- Load seller list for dropdown ---
$users = $conn->query('SELECT id,email FROM users WHERE role IN ("seller","admin") ORDER BY email');
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title><?php echo $id ? 'Edit Product' : 'Add Product'; ?></title>
  <link rel="stylesheet" href="/nepfoot_project/assets/style.css">
</head>
<body>
<?php include '../parts/header.php'; ?>

<main class="container card">
  <h2><?php echo $id ? 'Edit' : 'Add'; ?> Product</h2>

  <?php if($errors): ?>
    <div style="color:red">
      <ul><?php foreach($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; ?></ul>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label>Name</label>
      <input type="text" name="name" required value="<?php echo htmlspecialchars($name); ?>">
    </div>

    <div class="form-group">
      <label>Price</label>
      <input type="text" name="price" required value="<?php echo htmlspecialchars($price); ?>">
    </div>

    <div class="form-group">
      <label>Brand</label>
      <input type="text" name="brand" value="<?php echo htmlspecialchars($brand); ?>">
    </div>

    <div class="form-group">
      <label>Size</label>
      <input type="text" name="size" value="<?php echo htmlspecialchars($size); ?>">
    </div>

    <div class="form-group">
      <label>Seller (assign)</label>
      <select name="seller_id">
        <option value="">--admin/self--</option>
        <?php while($u = $users->fetch_assoc()): ?>
          <option value="<?php echo $u['id']; ?>" <?php echo ($seller_id == $u['id']) ? 'selected' : ''; ?>>
            <?php echo htmlspecialchars($u['email']); ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>

    <div class="form-group">
      <label>Description</label>
      <textarea name="description"><?php echo htmlspecialchars($description); ?></textarea>
    </div>

    <div class="form-group">
      <label>Product Image</label>
      <input type="file" name="image" accept="image/*">
      <?php if (!empty($image)): ?>
        <p>Current:</p>
        <img src="/nepfoot_project/uploads/<?php echo htmlspecialchars($image); ?>" width="120" style="border-radius:8px;">
      <?php endif; ?>
    </div>

    <button class="btn" type="submit">Save</button>
  </form>
</main>

<?php include '../parts/footer.php'; ?>
</body>
</html>
