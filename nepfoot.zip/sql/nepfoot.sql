-- SQL script for NepFoot project
-- Create database and tables. Paste into phpMyAdmin or run via mysql client.
CREATE DATABASE IF NOT EXISTS nepfoot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nepfoot;

-- users: roles = 'admin', 'seller', 'customer'
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','seller','customer') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- products: seller_id links to users.id (nullable for admin-added)
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seller_id INT DEFAULT NULL,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  size VARCHAR(50),
  brand VARCHAR(100),
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- sample admin user (password: admin123)
INSERT INTO users (name, email, password, role)
VALUES ('Admin User', 'admin@nepfoot.test', '$2b$12$TFzAqrp8Ktd89nUKMlIiTOdyhCUWN3qjbJvKQC3esTCJU6opXSNyC', 'admin');

-- sample seller user (password: seller123)
INSERT INTO users (name, email, password, role)
VALUES ('Seller User', 'seller@nepfoot.test', '$2b$12$dFKFgR.DOf49wGvICKH9E.1wej1cOjFOPsS6TyrRxg.b7ZHdqfvYC', 'seller');

-- sample customer user (password: customer123)
INSERT INTO users (name, email, password, role)
VALUES ('Customer User', 'customer@nepfoot.test', '$2b$12$5YOLgTpUp3cVQDFz1v.WYezzxQpUyDnwcc0ErNS2YN5aflP9HLiIq', 'customer');
