<?php
require_once '../includes/functions.php';
require_login();
$user = current_user();
if ($user['role'] !== 'admin') { echo 'Access denied'; exit; }

# Delete product
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // delete image file too
    $img = $conn->query("SELECT image FROM products WHERE id=$id")->fetch_assoc()['image'] ?? '';
    if (!empty($img)) {
        $path = __DIR__ . '/../uploads/' . $img;
        if (file_exists($path)) unlink($path);
    }

    $conn->query("DELETE FROM products WHERE id=$id");
    header('Location: products.php');
    exit;
}

$res = $conn->query('SELECT p.*, u.email as seller_email FROM products p LEFT JOIN users u ON p.seller_id=u.id ORDER BY p.created_at DESC');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin - Products</title>
<link rel="stylesheet" href="/nepfoot_project/assets/style.css">
<style>
    .thumb {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 6px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.15);
    }
</style>
</head>
<body>
<?php include '../parts/header.php'; ?>

<main class="container card">
  <h2>All Products <a class="btn" href="edit_product.php">Add Product</a></h2>

  <table>
    <tr>
      <th>Image</th>
      <th>ID</th>
      <th>Name</th>
      <th>Price</th>
      <th>Seller</th>
      <th>Actions</th>
    </tr>

    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td>
          <?php if (!empty($r['image'])): ?>
            <img src="/nepfoot_project/uploads/<?php echo htmlspecialchars($r['image']); ?>" class="thumb">
          <?php else: ?>
            <span style="color:#888;">No image</span>
          <?php endif; ?>
        </td>

        <td><?php echo $r['id']; ?></td>
        <td><?php echo htmlspecialchars($r['name']); ?></td>
        <td><?php echo $r['price']; ?></td>
        <td><?php echo htmlspecialchars($r['seller_email'] ?: 'Admin'); ?></td>

        <td>
          <a href="edit_product.php?id=<?php echo $r['id']; ?>">Edit</a> |
          <a href="?delete=<?php echo $r['id']; ?>" onclick="return confirm('Delete this product?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</main>

<?php include '../parts/footer.php'; ?>
</body>
</html>
